package put.io.patterns.implement;

public class SystemGarbageCollectorObserver implements SystemStateObserver {

    SystemState state;

    public void garbageCollector()
    {
        if (state.getAvailableMemory() < 200.00){
            System.out.println("Garbage collector here {o}_{o}");
        }
    }

    public void update(SystemMonitor monitor){
        this.state = monitor.getLastSystemState();
        garbageCollector();
    }
}
