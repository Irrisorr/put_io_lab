package put.io.patterns.implement;

public class SystemCoolerObserver implements SystemStateObserver {

    SystemState state;

    public void runCooler()
    {
        if (state.getCpuTemp() > 60.00){
            System.out.println("Increasing cooling ");
        }
    }

    public void update(SystemMonitor monitor){
        this.state = monitor.getLastSystemState();
        runCooler();
    }
}
